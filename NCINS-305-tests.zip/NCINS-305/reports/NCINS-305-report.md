# NCINS-305 · Получение документа из AlfaCapture

- Режим: **mock (локальный контур)**
- Старт: 25.08.2026 20:29:20 UTC
- Финиш: 25.08.2026 20:29:21 UTC
- Длительность: 0.59 с
- Python: 3.12.3 · Linux 6.12.94+

| Всего | Успех | Падение | Пропуск | Ошибка |
| ---: | ---: | ---: | ---: | ---: |
| 17 | 16 | 0 | 1 | 0 |

| Статус | Набор | Кейс | Время | Комментарий |
| --- | --- | --- | ---: | --- |
| Успех | NCINS-277 · generate-form | NCINS-277: генерация ПФ отдаёт documentIds — вход для download. | 0.003 с |  |
| Успех | NCINS-277 · generate-form | NCINS-277: без fileAttributes — 200 и id документа. | 0.002 с |  |
| Успех | NCINS-277 · generate-form | NCINS-277: без обязательного поля — 400. [customerData] | 0.001 с |  |
| Успех | NCINS-277 · generate-form | NCINS-277: без обязательного поля — 400. [managerData] | 0.001 с |  |
| Успех | NCINS-277 · generate-form | NCINS-277: без обязательного поля — 400. [groups] | 0.002 с |  |
| Успех | NCINS-305 · download | Позитив: скачать документ, созданный generate-form. | 0.043 с |  |
| Успех | NCINS-305 · download | fileId из комментария NCINS-305. На стенде документ мог истечь. | 0.002 с |  |
| Успех | NCINS-305 · download | NCINS-305: нет fileId — 400. | 0.002 с |  |
| Успех | NCINS-305 · download | NCINS-305: пустой fileId — 400. | 0.001 с |  |
| Успех | NCINS-305 · download | NCINS-305: fileId=null — 400. | 0.001 с |  |
| Успех | NCINS-305 · download | NCINS-305: fileId не UUID — 400. | 0.002 с |  |
| Успех | NCINS-305 · download | NCINS-305: неизвестный UUID — 404. | 0.001 с |  |
| Успех | NCINS-305 · download | NCINS-305: нет JSON-тела — 400. | 0.001 с |  |
| Успех | NCINS-305 · download | NCINS-305: GET вместо POST — 404/405. | 0.043 с |  |
| Пропуск | NCINS-305 · download | E2E на INT: generate-form → download PDF. | 0.000 с | Задайте NCINS_LIVE=1 для стенда INT |
| Успех | Клиент / инфраструктура | Служебное: mock отдаёт валидный PDF magic. | 0.000 с |  |
| Успех | Клиент / инфраструктура | Служебное: URL download/generate-form не теряет префикс сервиса. | 0.000 с |  |
